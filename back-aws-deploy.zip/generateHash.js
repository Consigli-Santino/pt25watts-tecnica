const bcrypt = require('bcryptjs');

async function generateHash() {
    try {
        const password = '123';
        const saltRounds = 10;
        const hash = await bcrypt.hash(password, saltRounds);
        console.log('Contraseña:', password);
        console.log('Hash generado:', hash);

        // Verificar que funciona
        const isValid = await bcrypt.compare(password, hash);
        console.log('Verificación:', isValid ? 'OK' : 'FALLO');

    } catch (error) {
        console.error('Error:', error);
    }
}

generateHash();